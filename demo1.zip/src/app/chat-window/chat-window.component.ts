import { Component, OnInit, ElementRef, ViewChild, AfterViewChecked, ChangeDetectorRef, AfterViewInit, OnDestroy } from '@angular/core';
import { DataService } from '../home/data.service';
import { Socket } from 'ngx-socket-io';
import { Router } from '@angular/router';
@Component({
  selector: 'app-chat-window',
  templateUrl: './chat-window.component.html',
  styleUrls: ['./chat-window.component.css']
})
export class ChatWindowComponent implements OnInit, AfterViewChecked, OnDestroy {

  // itemList = ITEMS;
  @ViewChild('chatLog', { static: false }) chatLog: ElementRef;
  @ViewChild('fileInput', { static: false }) el: ElementRef;
  imageUrl: any;
  chatList = [];
  message: string;
  username: string;
  avatar: any;
  user: any;
  room: string;
  isLoading = false;
  constructor(private router: Router, private dataTranfer: DataService, private socket: Socket, private cd: ChangeDetectorRef) {
    this.dataTranfer.user.subscribe(user => this.user = user);
    if (!this.user) {
      this.router.navigate(['/login']);
    } else {
      this.socket.on('message_list_res', (data) => {
        this.chatList = data.list;
      });
      this.socket.on('chat_res', (data) => {
        console.log('nhan dc tin nhan moi');
        const chatlog = data.content;
        this.chatList.push(chatlog);
      }
      );
    }

  }

  ngOnInit() {
    this.chatList = [];
    this.dataTranfer.userName.subscribe(username => this.username = username);
    this.dataTranfer.avatar.subscribe(avatar => this.avatar = avatar);
    this.dataTranfer.roomName.subscribe(roomName => this.room = roomName);
    this.socket.emit('message_list_req', { room: this.room });
  }

  ngAfterViewChecked(): void {
    this.chatLog.nativeElement.scrollTop = this.chatLog.nativeElement.scrollHeight;
  }

  ngOnDestroy() {
    this.socket.removeAllListeners();
  }

  chat() {
    this.isLoading = true;
    if (this.message) {
      this.socket.emit('chat_req', { room: this.room, user: this.user, message: this.message, image: '' });
      this.message = '';
    }
  }
  uploadFile(event) {
    const reader = new FileReader(); // HTML5 FileReader API
    const file = event.target.files[0];
    if (event.target.files && event.target.files[0]) {
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.imageUrl = reader.result;
        this.socket.emit('chat_req', { room: this.room, user: this.user, message: '', image: this.imageUrl });
      };
      // ChangeDetectorRef since file is loading outside the zone
      this.cd.markForCheck();
    }
  }
}
