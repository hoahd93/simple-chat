import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../home/data.service';
import { Socket } from 'ngx-socket-io';

@Component({
  selector: 'app-chat-room',
  templateUrl: './chat-room.component.html',
  styleUrls: ['./chat-room.component.css']
})
export class ChatRoomComponent implements OnInit {
  roomName: string;
  rooms = [];
  users = [];
  user: any;
  isOverlay = false;
  isLoading1 = false;
  isLoading2 = false;
  validMessage = '';
  isRoomNameDuplicate = false;
  constructor(private router: Router, private dataTranfer: DataService, private socket: Socket, private cd: ChangeDetectorRef) {
    this.dataTranfer.user.subscribe(user => this.user = user);
    if (!this.user) {
      this.router.navigate(['/login']);
    }
  }

  ngOnInit() {
    this.dataTranfer.user.subscribe(user => this.user = user);
    this.socket.emit('room_list_req', {});
    this.socket.emit('user_list_req', { user: this.user });
    this.isLoading1 = true;
    this.socket.on('room_list_res', async (data) => {
      this.rooms = await data.res;
      this.isLoading1 = false;
    });
    this.isLoading2 = true;
    this.socket.on('user_list_res', (data) => {
      this.users = data.res;
      this.isLoading2 = false;
    });

  }

  createRoom() {
    this.isOverlay = true;
    this.isRoomNameDuplicate = false;
    this.socket.emit('create_room_req', this.roomName);
    this.socket.on('create_room_res', (data) => {
      if (data.result) {
        this.validMessage = '';
        this.dataTranfer.changeRoom(data.name);
        setTimeout(() => { this.isOverlay = false; }, 1000);
        this.router.navigate(['/chat']);
      } else {
        setTimeout(() => { this.isOverlay = false; }, 1000);
        this.validMessage = 'The room name is already taken';
        this.isRoomNameDuplicate = true;
      }
    });
  }

  selectRoom(room: any) {
    this.isOverlay = true;
    this.socket.emit('select_room_req', room.name);
    this.socket.on('select_room_res', (data) => {
      if (data) {
        this.dataTranfer.changeRoom(data.name);
        this.router.navigate(['/chat']);
      }
      setTimeout(() => { this.isOverlay = false; }, 1000);
    });
  }

  selectUser(userId: any) {
    this.isOverlay = true;
    this.socket.emit('select_user_req', { user1: this.user._id, user2: userId });
    console.log(this.user._id);
    this.socket.on('select_user_res', (data) => {
      if (data.result !== 3) {
        this.dataTranfer.changeRoom(data.name);
        this.router.navigate(['/chat']);
      } else {
        console.log('Error when create private chat');
      }
      setTimeout(() => { this.isOverlay = false; }, 1000);
    });
  }

}
