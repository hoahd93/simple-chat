import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private userNameSource = new BehaviorSubject('');
  userName = this.userNameSource.asObservable();
  private avatarSource = new BehaviorSubject('');
  avatar = this.avatarSource.asObservable();
  private userSource = new BehaviorSubject('');
  user = this.userSource.asObservable();
  private roomSource = new BehaviorSubject('');
  roomName = this.roomSource.asObservable();

  constructor() { }

  changeNickName(userName: string) {
    this.userNameSource.next(userName);
  }
  changeAvatar(avatar: any) {
    this.avatarSource.next(avatar);
  }
  changeUser(user: any) {
    this.userSource.next(user);
  }
  changeRoom(roomName: string) {
    this.roomSource.next(roomName);
  }
}
