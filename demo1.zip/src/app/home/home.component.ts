import { Component, OnInit, ChangeDetectorRef, ElementRef, ViewChild, ViewEncapsulation } from '@angular/core';
import { DataService } from './data.service';
import { Socket } from 'ngx-socket-io';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class HomeComponent implements OnInit {
  @ViewChild('fileInput', { static: false }) el: ElementRef;
  imageUrl: any = 'https://i.pinimg.com/236x/d6/27/d9/d627d9cda385317de4812a4f7bd922e9--man--iron-man.jpg';
  username: string;
  user: any;
  password: string;
  password1: string;
  password2: string;
  phone: string;
  email: string;
  room: string;
  isLogin = true;
  isLoginErr = false;
  isConfirmPassword = true;
  isUsername = true;
  isPassword = true;
  isPhone = true;
  isEmail = true;
  isRegSuccess = true;
  isLoginSuccess = false;
  isOverlay = false;
  validUsernameMessage = '';
  validPasswordMessage1 = '';
  validPasswordMessage2 = '';
  validPhoneMessage = '';
  validEmailMessage = '';
  constructor(private router: Router, private dataTranfer: DataService, private socket: Socket, private cd: ChangeDetectorRef) { }

  ngOnInit() {
    // this.data.nickName.subscribe(nickName => this.nickName = nickName);
  }

  login() {
    this.isOverlay = true;
    this.socket.emit('login_req', { username: this.username, password: this.password });
    this.socket.on('login_res', (data) => {
      this.isLoginSuccess = data.result;
      this.user = data.user;
      this.dataTranfer.changeUser(this.user);
      if (this.isLoginSuccess) {
        console.log('Login success');
        this.router.navigate(['/room']);
      } else {
        this.isLoginErr = true;
      }
      this.isOverlay = false;
    });
  }



  uploadFile(event) {
    const reader = new FileReader(); // HTML5 FileReader API
    const file = event.target.files[0];
    if (event.target.files && event.target.files[0]) {
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.imageUrl = reader.result;
      };
      // ChangeDetectorRef since file is loading outside the zone
      this.cd.markForCheck();
    }
  }

  registerUser() {
    this.validUsername();
    this.validPassword();
    this.validPhone();
    this.validEmail();
    this.validConfirmPassword();
    if (this.isUsername && this.isPassword && this.isPhone && this.isEmail && this.isConfirmPassword) {
      this.isOverlay = true;
      this.socket.emit('reg_req', {
        name: this.username, password: this.password1, phone: this.phone,
        email: this.email, avatar: this.imageUrl
      });
      this.socket.on('reg_res', (data) => {
        if (data.result) {
          this.isRegSuccess = true;
          this.isLogin = true;
        } else {
          this.isRegSuccess = false;
        }
      });
      setTimeout(() => { this.isOverlay = false; }, 1000);
    }
  }

  validUsername() {
    if (!this.username) {
      this.isUsername = false;
      this.validUsernameMessage = 'Username can not be empty!';
    } else {
      this.isUsername = true;
      this.validUsernameMessage = '';
    }
  }

  validPassword() {
    if (!this.password1) {
      this.isPassword = false;
      this.validPasswordMessage1 = 'Password can not be empty!';
    } else {
      this.isPassword = true;
      this.validPasswordMessage1 = '';
    }
  }

  validConfirmPassword() {
    if (this.password1 === this.password2) {
      this.isConfirmPassword = true;
      this.validPasswordMessage2 = '';
    } else {
      this.isConfirmPassword = false;
      this.validPasswordMessage2 = 'Confirm password not match!';
    }
  }

  validPhone() {
    if (this.phone && /^([0-9]){10,11}$/g.test(this.phone) || !this.phone) {
      this.isPhone = true;
      this.validPhoneMessage = '';
    } else {
      this.isPhone = false;
      this.validPhoneMessage = 'Wrong phone number format!';
    }
  }

  validEmail() {
    if (this.email && /^([a-z0-9A-Z](\.?[a-z0-9A-Z]){1,})\@\w+([\.-]?\w+)+$/.test(this.email) || !this.email) {
      this.isEmail = true;
      this.validEmailMessage = '';
    } else {
      this.isEmail = false;
      this.validEmailMessage = 'Wrong email format!';
    }
  }

}
